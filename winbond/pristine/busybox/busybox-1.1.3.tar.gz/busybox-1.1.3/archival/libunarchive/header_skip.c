#include <stdio.h>
#include "unarchive.h"

void header_skip(const file_header_t *file_header ATTRIBUTE_UNUSED)
{
}
